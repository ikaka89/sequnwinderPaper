use strict;

my $stamp_out = $ARGV[0];


open(ST,$stamp_out);

my $check = 0;
my $currMotName = "";

while(<ST>){
	chomp $_;
	if(/^>/){
		$check = 1;
		my @pieces = split("\t",$_);
		$currMotName = $pieces[1];
	}elsif($check == 1){
		my @pieces = split("\t",$_);
		print $currMotName,"\t",$pieces[0],"\n";
		$check = 0;
	}
}	
